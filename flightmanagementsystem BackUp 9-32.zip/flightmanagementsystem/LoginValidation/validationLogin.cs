﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseOperation;
using System.Data;
using System.Net.Mail;
using System.Data.SqlClient;

namespace LoginValidation
{
    public class validationLogin
    {
        public string username { get; set; }
        public int RoleID { get; set; }
        public string Email { get; set; }
        public string StateId { get; set; }
        RegistrationClass register = new RegistrationClass();
        DataSet ds = new DataSet();
        DatabaseConnection data = new DatabaseConnection();

        //method to check if user is admin, staff or user or has no account in the system
        public validationLogin validateUser(string _username, string _password, out int check)
        {
            check = 0;
            validationLogin returnValue = new validationLogin();
            register.UserName = _username;
            register.Password = _password;
            ds = data.GetRoleDropDownData(register, out check);
            if (check == 1)
            {
                DataRow dr = ds.Tables[0].Rows[0];
                returnValue.username = dr["Username"].ToString();
                returnValue.RoleID = Convert.ToInt32(dr["Rid"]);
                return returnValue;
            }
            else
            {
                returnValue.username = "-1";
                returnValue.RoleID = -1;
                return returnValue;
            }

        }
        //method to reset password
        public int ResetPassword(string _email, string _stateid)
        {
            int check =0;
            
            register.Email = _email;
            register.StateId = _stateid;

            ds=data.GetEmailAndStateId(register, out check);

            if (check == 1)
            {
                DataRow dr2 = ds.Tables[0].Rows[0];
                string UniqueID = dr2["UniqueId"].ToString();
                MailMessage mail = new MailMessage("flightmanagementsystem@gmail.com", register.Email);
                StringBuilder sbEmailBody = new StringBuilder();
                sbEmailBody.Append("Please click the following link to reset the password ");
                sbEmailBody.Append("<br/>");
                sbEmailBody.Append("http://localhost/FlightReservation/ChangePassword.aspx?uid=" + UniqueID);

                mail.IsBodyHtml = true;
                mail.Body = sbEmailBody.ToString();
                mail.Subject = "Reset Your Password";
                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587);
                smtpClient.Credentials = new System.Net.NetworkCredential()
                {
                    UserName = "flightmanagementsystem@gmail.com",
                    Password = "Lamar@123"

                };
                smtpClient.EnableSsl = true;
                smtpClient.Send(mail);
                return check;
            }
            else
            {
                return check;
            }
           
        
        }

       

    }
}
