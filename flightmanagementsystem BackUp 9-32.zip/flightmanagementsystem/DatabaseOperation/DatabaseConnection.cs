﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseOperation
{
    public class Schedule
    {
        public int SId { get; set; }
        public int FId { get; set; }
        public string DepartureState { get; set; }
        public string DepartureCity { get; set; }
        public string ArrivalState { get; set; }
        public string ArrivalCity { get; set; }
        public string FlightTime { get; set; }
        public string Duration { get; set; }
        public string FlightDate { get; set; }
        public string Cost { get; set; }

    }

    public class DatabaseConnection
    {
        String cs = System.Configuration.ConfigurationManager.ConnectionStrings["DBCS"].ToString();
        public DataSet Getdata(string spname, SqlParameter spparameter)
        {

            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlDataAdapter sda = new SqlDataAdapter(spname, con);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                if (spparameter != null)
                {
                    sda.SelectCommand.Parameters.Add(spparameter);
                }
                DataSet ds = new DataSet();
                sda.Fill(ds);
                return ds;
            }

        }
        public DataSet GetUserInput(string spname, SqlParameter spparameter1, SqlParameter spparameter2, SqlParameter spparameter3, SqlParameter spparameter4, SqlParameter spparameter5, SqlParameter spparameter6)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlDataAdapter sda = new SqlDataAdapter(spname, con);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sda.SelectCommand.Parameters.Add(spparameter1);
                sda.SelectCommand.Parameters.Add(spparameter2);
                sda.SelectCommand.Parameters.Add(spparameter3);
                sda.SelectCommand.Parameters.Add(spparameter4);
                sda.SelectCommand.Parameters.Add(spparameter5);
                sda.SelectCommand.Parameters.Add(spparameter6);

                DataSet ds = new DataSet();
                sda.Fill(ds);
                return ds;
            }
        }
        public void InsertIntoSchedule(int SId, int UId, int seats, int status, string date)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("spUserInputInsert", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UId", UId);
                cmd.Parameters.AddWithValue("@SId", SId);
                cmd.Parameters.AddWithValue("@Seats", seats);
                cmd.Parameters.AddWithValue("@Status", status);
                cmd.Parameters.AddWithValue("@Date", date);
                con.Open();
                cmd.ExecuteNonQuery();


            }

        }

        public DataSet GetUserInputde(string spname, SqlParameter spparameter)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlDataAdapter sda = new SqlDataAdapter(spname, con);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sda.SelectCommand.Parameters.Add(spparameter);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                return ds;
            }
        }

        public void DeleteInput(int id)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("spDeleteItemById", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", id);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
        public DataSet GetRoleDropDownData()
        {

            SQLOperations sp = new SQLOperations();
            DataSet ds = sp.GetData("spGetRoleData", null);
            return ds;
            //using (SqlConnection con = new SqlConnection(cs)) {
            //    SqlCommand cmd =new SqlCommand("spGetRoleData", con);
            //    cmd.CommandType = CommandType.StoredProcedure;
            //    SqlDataAdapter da = new SqlDataAdapter(cmd);
            //    DataSet ds = new DataSet();
            //    da.Fill(ds);
            //    return ds;
            //}
        }

        public DataSet GetStateData()
        {
            SQLOperations sp = new SQLOperations();
            DataSet ds = sp.GetData("spGetStateData", null);
            return ds;
            //using (SqlConnection con = new SqlConnection(cs)) {
            //    SqlCommand cmd = new SqlCommand("spGetStateData", con);
            //    cmd.CommandType = CommandType.StoredProcedure;
            //    SqlDataAdapter da = new SqlDataAdapter(cmd);
            //    DataSet ds = new DataSet();
            //    da.Fill(ds);
            //    return ds;
            //}
        }

        public DataSet GetCityData(string stateName)
        {
            SQLOperations sp = new SQLOperations();
            SqlParameter sq = new SqlParameter();
            sq.ParameterName = "@StateName";
            sq.Value = stateName;
            DataSet ds = sp.GetData("spGetCityByStateId", sq);
            return ds;
            //using (SqlConnection con = new SqlConnection(cs))
            //{
            //    SqlCommand cmd = new SqlCommand("spGetCityByStateId", con);
            //    cmd.CommandType = CommandType.StoredProcedure;
            //    cmd.Parameters.AddWithValue("@StateName", stateName);
            //    SqlDataAdapter da = new SqlDataAdapter(cmd);
            //    DataSet ds = new DataSet();
            //    da.Fill(ds);
            //    return ds;
            //}
        }

        //validation of the username to find out if its unique or not
        public bool ValidateUniqueUserName(string username)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("spUserNameValidation", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", username);
                con.Open();
                if ((int)cmd.ExecuteScalar() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        //inserting user data into the table
        public bool InsertData(RegistrationClass rc)
        {

            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("spInsertUserDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserName", rc.UserName);
                cmd.Parameters.AddWithValue("@Password", rc.Password);
                cmd.Parameters.AddWithValue("@RID", rc.Role);
                cmd.Parameters.AddWithValue("@Fname", rc.FirstName);
                cmd.Parameters.AddWithValue("@Lname", rc.LastName);
                cmd.Parameters.AddWithValue("@Email", rc.Email);
                cmd.Parameters.AddWithValue("@Phone", rc.PhoneNo);
                cmd.Parameters.AddWithValue("@StateId", rc.StateId);
                cmd.Parameters.AddWithValue("@StreetAddress", rc.StreetAddress);
                cmd.Parameters.AddWithValue("@City", rc.City);
                cmd.Parameters.AddWithValue("@State", rc.State);
                cmd.Parameters.AddWithValue("@ZIPCode", rc.ZIPCode);
                con.Open();
                int res = cmd.ExecuteNonQuery();
                if (res > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        // Getting the data of user to displaying it in the update page at start
        public RegistrationClass GetAllUserDataForUpdate(string username)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlDataAdapter da = new SqlDataAdapter("spGetAllDataForUpdate", con);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                SqlParameter sq = new SqlParameter("@username", username);
                da.SelectCommand.Parameters.Add(sq);
                DataTable dt = new DataTable();
                da.Fill(dt);
                RegistrationClass rc = new RegistrationClass();
                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];
                    rc.FirstName = row["Fname"].ToString();
                    rc.LastName = row["Lname"].ToString();
                    rc.Email = row["Email"].ToString();
                    rc.PhoneNo = row["Phone"].ToString();
                    rc.StateId = row["StateId"].ToString();
                    rc.StreetAddress = row["StreetAddress"].ToString();
                    rc.City = row["City"].ToString();
                    rc.ZIPCode = (int)row["ZIPCode"];

                }
                return rc;
            }
        }


        // Updating the User information 
        public bool UpdateUserInformation(RegistrationClass rs)
        {

            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("spUpdateUserDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", rs.UserName);
                cmd.Parameters.AddWithValue("@Fname", rs.FirstName);
                cmd.Parameters.AddWithValue("@Lname", rs.LastName);
                cmd.Parameters.AddWithValue("@Email", rs.Email);
                cmd.Parameters.AddWithValue("@Phone", rs.PhoneNo);
                cmd.Parameters.AddWithValue("@StateId", rs.StateId);
                cmd.Parameters.AddWithValue("@StreetAddress", rs.StreetAddress);
                cmd.Parameters.AddWithValue("@City", rs.City);
                cmd.Parameters.AddWithValue("@State", rs.State);
                cmd.Parameters.AddWithValue("@ZIPCode", rs.ZIPCode);
                con.Open();
                int res = cmd.ExecuteNonQuery();
                if (res > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
        }


        //delete user data
        public bool DeleteUserData(string username)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand com = new SqlCommand("spDeleteUserDetails", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@username", username);
                con.Open();
                int res = com.ExecuteNonQuery();
                if (res > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }


        //get required parameters for sending activation email
        public void GetActivationParameter(string username)
        {
            bool flag = false;
            using (SqlConnection con = new SqlConnection(cs))
            {

                SqlCommand cmd = new SqlCommand("spSetReqActivationData", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", username);
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    flag = Convert.ToBoolean(rdr["ReturnCode"]);
                    if (flag)
                    {
                        SendEmail se = new SendEmail();
                        se.SendStatusSetEmail(rdr["Email"].ToString(), username, rdr["UniqueId"].ToString());
                    }
                }
            }
            //return flag;
        }

        //class to validate the activation link
        public bool checkActivationLinkValidation(string guid)
        {
            SQLOperations sq = new SQLOperations();
            return sq.ActivationLinkValidation("spIsActivationLinkValid", guid);
        }

        //activate the user
        public bool ActivateUser(string guid)
        {
            List<SqlParameter> paramList = new List<SqlParameter>()
            {
                new SqlParameter()
                {
                    ParameterName = "@guid",
                    Value = guid
                }
            };
            SQLOperations sq = new SQLOperations();
            return sq.ExecuteSP("spChangeStatusToActive", paramList);
        }



        // login checking 
        public DataSet GetRoleDropDownData(RegistrationClass register, out int check)
        {

            check = 0;
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("spLoginCheck", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", register.UserName);
                cmd.Parameters.AddWithValue("@password", register.Password);
                SqlParameter sqlParameter = new SqlParameter();
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                //cmd.Parameters.Add()
                //SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                check = da.Fill(ds);
                return ds;
            }
        }

        //Check for email and username to change password

        public DataSet GetEmailAndStateId(RegistrationClass register, out int check)
        {

            check = 0;
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("spResetPassword", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Email", register.Email);
                cmd.Parameters.AddWithValue("@StateId", register.StateId);
                SqlParameter sqlParameter = new SqlParameter();
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                //cmd.Parameters.Add()
                //SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                check = da.Fill(ds);
                return ds;
            }
        }
        public bool ExecuteSP(string SPName, List<SqlParameter> SpParameters)
        {



            using (SqlConnection con = new SqlConnection(cs))
            {
                int check = 0;
                SqlCommand cmd = new SqlCommand(SPName, con);
                cmd.CommandType = CommandType.StoredProcedure;
                foreach (SqlParameter parameter in SpParameters)
                {
                    cmd.Parameters.Add(parameter);
                }
                SqlParameter sqlParameter = new SqlParameter();
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                //cmd.Parameters.Add()
                //SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                check = da.Fill(ds);
                return Convert.ToBoolean(cmd.ExecuteScalar());
            }
        }

        //change password
        public bool ExecuteSP1(string SPName, List<SqlParameter> SpParameters)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand(SPName, con);
                cmd.CommandType = CommandType.StoredProcedure;
                foreach (SqlParameter parameter in SpParameters)
                {
                    cmd.Parameters.Add(parameter);
                }
                con.Open();
                //stored procedure is going to return a single scalar value
                return Convert.ToBoolean(cmd.ExecuteScalar());
            }
        }
        public int getUserid(string uname)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("spgetUserId", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", uname);
                con.Open();
                //stored procedure is going to return a single scalar value
                return Convert.ToInt32(cmd.ExecuteScalar());
            }

        }
        public DataTable ddlAirlineCompany()
        {
            
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand com = new SqlCommand();
                com.CommandText = "spDDLAirlines";
                com.CommandType = CommandType.StoredProcedure;
                com.Connection = con;
                con.Open();
                SqlDataAdapter adp = new SqlDataAdapter(com);
                DataTable data = new DataTable();
                adp.Fill(data);
                return data;
            }
        }
        public int FlightDetailsInsert(int AirID, string fNum, int fSeats)
        {
            
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand com = new SqlCommand();
                com.CommandText = "spFlightDetailsInsert";
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@AirlineID", AirID);
                com.Parameters.AddWithValue("@FlightNum", fNum);
                com.Parameters.AddWithValue("@FlightSeats", fSeats);
                com.Connection = con;
                con.Open();
                int i = com.ExecuteNonQuery();
                if (i == 1)
                {
                    return i;
                }
                else
                {
                    return 0;
                }
            }
        }
        public DataTable gridviewFlights()
        {
            
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand com = new SqlCommand();
                com.CommandText = "spViewAllFlightDetails";
                com.CommandType = CommandType.StoredProcedure;
                com.Connection = con;
                con.Open();
                SqlDataAdapter adp = new SqlDataAdapter(com);
                DataTable data = new DataTable();
                adp.Fill(data);
                return data;
            }
        }
        public int checkFlightNum(string fnum)
        {
            
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand com = new SqlCommand();
                com.CommandText = "spSearchFlightNum";
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@fnum", fnum);
                com.Connection = con;
                con.Open();
                int i = Convert.ToInt32(com.ExecuteScalar());
                if (i > 0)
                {
                    return i;
                }
                else
                {
                    return 0;
                }
            }
        }
        public int DeleteFlight(string fnum)
        {
            
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand com = new SqlCommand();
                com.CommandText = "spFlightDetailsDelete";
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@FlightNum", fnum);
                com.Connection = con;
                con.Open();
                int i = com.ExecuteNonQuery();
                if (i == 1)
                {
                    return i;
                }
                else
                {
                    return 0;
                }
            }
        }
        public DataSet ViewFlightByFNum(string fnum)
        {
            
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlDataAdapter sdr = new SqlDataAdapter("spViewIndividialFlight", con);
                sdr.SelectCommand.CommandType = CommandType.StoredProcedure;
                sdr.SelectCommand.Parameters.AddWithValue("@fnum", fnum);
                con.Open();
                DataSet DS = new DataSet();
                sdr.Fill(DS);
                return DS;
            }
        }
        public int UpdateFlight(string fnum, int seats, int aid, int fid)
        {
            
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand com = new SqlCommand();
                com.CommandText = "spFlightDetailsUpdate";
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@FId", fid);
                com.Parameters.AddWithValue("@AirlineID", aid);
                com.Parameters.AddWithValue("@FlightNum", fnum);
                com.Parameters.AddWithValue("@FlightSeats", seats);
                com.Connection = con;
                con.Open();
                int i = Convert.ToInt32(com.ExecuteScalar());
                if (i > 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
        }
        public DataSet DropDownAirline()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            //string query = "SELECT AirId, AirlineName from tbl_AirlineDetails";
            string query = "EXECUTE spImportAirlineName";
            SqlCommand command = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(command);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;

        }

        

        public void AddSchedule(string airlinenumber, string flightnum, string DepartureState, int DepartureCity, string ArrivalState, int ArrivalCity, string FlightTime, string FlightDuration, string FlightDate, int Cost)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                string sqlstr = "EXECUTE spFlightScheduleInsert " + int.Parse(airlinenumber) + ",'" + flightnum + "', '" + DepartureState + "'," + DepartureCity + ", '" + ArrivalState + "','" + ArrivalCity + "','" + FlightTime + "','" + FlightDuration + "','" + FlightDate + "'," + Cost + "";
                SqlCommand cmd = new SqlCommand(sqlstr, con);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public int GetFId(string FlightNum)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                string sqlstr = "EXECUTE spGetFlightId + " + FlightNum + " ";
                SqlCommand cmd = new SqlCommand(sqlstr, con);
                con.Open();
                int FId = (int)cmd.ExecuteScalar();
                return FId;
            }
        }

        public DataSet Result()
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                string sqlstr = "EXECUTE spResult";
                SqlDataAdapter sda = new SqlDataAdapter(sqlstr, con);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                return ds;
            }
        }

        public List<Schedule> GetAllSchedule()
        {
            List<Schedule> listSchedule = new List<Schedule>();
            

            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("Select * from tbl_FlightSchedule", con);
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Schedule schedule = new Schedule();
                    schedule.SId = Convert.ToInt32(rdr["SId"]);
                    schedule.FId = Convert.ToInt32(rdr["FId"]);
                    schedule.DepartureState = rdr["DepartureState"].ToString();
                    schedule.DepartureCity = rdr["DepartureCity"].ToString();
                    schedule.ArrivalState = rdr["ArrivalState"].ToString();
                    schedule.ArrivalCity = rdr["ArrivalCity"].ToString();
                    schedule.FlightTime = rdr["FlightTime"].ToString();
                    schedule.Duration = rdr["Duration"].ToString();
                    schedule.FlightDate = rdr["FlightDate"].ToString();
                    schedule.Cost = rdr["Cost"].ToString();

                    listSchedule.Add(schedule);
                }
            }

            return listSchedule;
        }

        public void UpdateSchedule(int SId, int FId, string DepartureState, int DepartureCity, string ArrivalState, int ArrivalCity, string FlightTime, string Duration, string FlightDate, int Cost)
        {
            
            using (SqlConnection con = new SqlConnection(cs))
            {

                string updateQuery = "UPDATE tbl_FlightSchedule SET FId = @FId, DepartureState = @DepartureState, DepartureCity = @DepartureCity, ArrivalState = @ArrivalState, ArrivalCity = @ArrivalCity, FlightTime = @FlightTime, Duration = @Duration, FlightDate = @FlightDate, Cost=@Cost where SId = @SId";

                SqlCommand cmd = new SqlCommand(updateQuery, con);
                SqlParameter paramSId = new SqlParameter("@SId", SId);
                cmd.Parameters.Add(paramSId);
                SqlParameter paramFId = new SqlParameter("@FId", FId);
                cmd.Parameters.Add(paramFId);
                SqlParameter paramDepartureState = new SqlParameter("@DepartureState", DepartureState);
                cmd.Parameters.Add(paramDepartureState);
                SqlParameter paramDepartureCity = new SqlParameter("@DepartureCity", DepartureCity);
                cmd.Parameters.Add(paramDepartureCity);
                SqlParameter paramArrivalState = new SqlParameter("@ArrivalState", ArrivalState);
                cmd.Parameters.Add(paramArrivalState);
                SqlParameter paramArrivalCity = new SqlParameter("@ArrivalCity", ArrivalCity);
                cmd.Parameters.Add(paramArrivalCity);
                SqlParameter paramFlightTime = new SqlParameter("@FlightTime", FlightTime);
                cmd.Parameters.Add(paramFlightTime);
                SqlParameter paramDuration = new SqlParameter("@Duration", Duration);
                cmd.Parameters.Add(paramDuration);
                SqlParameter paramFlightDate = new SqlParameter("@FlightDate", FlightDate);
                cmd.Parameters.Add(paramFlightDate);
                SqlParameter paramCost = new SqlParameter("@Cost", Cost);
                cmd.Parameters.Add(paramCost);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

    }
}
