﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using DatabaseOperation;
using System.Data;

namespace FlightManagementSystem
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

        // DatabaseConnection connection = new DatabaseConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!IspasswordResetLinkValid())
                {
                    lblChangeStatus.ForeColor = System.Drawing.Color.Red;
                    lblChangeStatus.Text = "Password Reset Link has expired or invalid";
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (ChangeUserPassword())
            {
                
                
                // lblChangeStatus.Text = "";

                Response.Redirect("~/Login.aspx?id=1");

            }
            else
            {
                
                lblChangeStatus.ForeColor = System.Drawing.Color.Red;
                lblChangeStatus.Text = "Password reset link has expired or is invalid";
            }

        }

        private bool ChangeUserPassword()
        {
            //List<SqlParameter> param = new List<SqlParameter>();
            //{
            //    new SqlParameter()
            //    {
            //        ParameterName = "@GUID",
            //        Value = Request.QueryString["uid"]

            //    };

            //    new SqlParameter()
            //    {
            //        ParameterName = "@Password",
            //        Value = txtPassword.Text
            //    };
            //    return ExecuteSP("spChangePassword", param);

            //}

            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("spChangePassword", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@GUID", Request.QueryString["uid"]);
                cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

                //foreach (SqlParameter parameter in SpParameters)
                //{
                //    cmd.Parameters.Add(parameter);
                //}
                con.Open();
                //stored procedure is going to return a single scalar value
                return Convert.ToBoolean(cmd.ExecuteScalar());
            }


        }


        private bool IspasswordResetLinkValid()
        {
            List<SqlParameter> paramList = new List<SqlParameter>();
            {
                new SqlParameter()
                {
                    ParameterName = "@GUID",
                    Value = Request.QueryString["uid"]
                };
                return ExecuteSP("spIsPasswordResetLinkValid", paramList);
            }

        }


        public bool ExecuteSP(string SPName, List<SqlParameter> SpParameters)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand(SPName, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@GUID", Request.QueryString["uid"]);
                foreach (SqlParameter parameter in SpParameters)
                {
                    cmd.Parameters.Add(parameter);
                }
                con.Open();
                //stored procedure is going to return a single scalar value
                return Convert.ToBoolean(cmd.ExecuteScalar());
            }
        }


    }
}