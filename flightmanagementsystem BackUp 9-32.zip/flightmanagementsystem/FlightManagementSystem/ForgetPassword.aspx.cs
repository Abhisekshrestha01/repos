﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LoginValidation;

namespace FlightManagementSystem
{
    public partial class ForgetPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnResetPassword_Click(object sender, EventArgs e)
        {
            int check = 0;
            validationLogin resetPass = new validationLogin();
            //validation of email left to implement
            string Email = txtEmail.Text;
            string StateId = txtStateId.Text; 
            
           check= resetPass.ResetPassword(Email, StateId);
            if (check == 1)
            {
                lblResetStatus.Text = "An email has been sent to reset you password";
                txtEmail.Text = "";
                txtStateId.Text = "";
            }

            else
            {
                txtEmail.Text = "";
                txtStateId.Text = "";
                lblResetStatus.Text = "Account cannot be found. Please enter valid email or state id";
               

            }
        }

        protected void btnChangePassword_Click(object sender, EventArgs e)
        {

        }
    }
}