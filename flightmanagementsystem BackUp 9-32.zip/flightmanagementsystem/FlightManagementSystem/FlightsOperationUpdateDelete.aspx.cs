﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseOperation;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;

namespace FlightManagementSystem
{
    public partial class FlightsOperationUpdateDelete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonDelete_Click(object sender, EventArgs e)
        {
            string fnumToDelete=TextBoxUpdateDel.Text;
            Regex exp = new Regex(@"^[A-Z]{2}\d{4}$");
            Match mat = exp.Match(fnumToDelete);
            if(fnumToDelete=="")
            {
                Response.Write("<script>alert('Flight Number cannot be Empty')</script>");
            }
            else if (mat.Success && fnumToDelete != "")
            {
                DatabaseConnection datacon = new DatabaseConnection();
                int i = datacon.DeleteFlight(fnumToDelete);
                if (i == 1)
                {
                    Response.Write("<script>alert('Flight was Successfully Deleted FlightID: " + fnumToDelete + "')</script>");

                }
                else
                {
                    Response.Write("<script>alert('Flight with FlightID: " + fnumToDelete + " not found')</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Flight was not submitted in right format please check ex:AA1234')</script>");
            }
        }

        protected void bindDDLData()
        {
            DatabaseConnection dataconn = new DatabaseConnection();
            DDLFlightReseration.DataSource = dataconn.ddlAirlineCompany();
            DDLFlightReseration.DataBind();
            DDLFlightReseration.DataTextField = "AirlineName";
            DDLFlightReseration.DataValueField = "AirId";
            DDLFlightReseration.DataBind();
            DDLFlightReseration.Items.Insert(0, new ListItem("-----SELECT-----", "0"));
        }
        protected void ButtonUpdate_Click(object sender, EventArgs e)
        {
            string fnumToUpdate = TextBoxUpdateDel.Text;
            Regex exp = new Regex(@"^[A-Z]{2}\d{4}$");
            Match mat = exp.Match(fnumToUpdate);
            if (fnumToUpdate == "")
            {
                Response.Write("<script>alert('Flight Number cannot be Empty')</script>");
            }
            else if (mat.Success && fnumToUpdate != "")
            {
                DatabaseConnection datacon = new DatabaseConnection();
                int i = datacon.checkFlightNum(fnumToUpdate);
                if (i == 1)
                {
                    contentPanel.Visible = true;
                    UpdateFlighNumTable.Visible = true;
                    bindDDLData();
                    DataSet ds = datacon.ViewFlightByFNum(fnumToUpdate);
                    if(ds.Tables[0].Rows[0]!=null)
                    {
                        
                        TextBoxUpdatedFlightNum.Text = (ds.Tables[0].Rows[0]["FlightNum"].ToString());
                        TextBoxUpdatedSeats.Text = (ds.Tables[0].Rows[0]["FlightSeats"].ToString());
                        DDLFlightReseration.SelectedValue = (ds.Tables[0].Rows[0]["AirID"].ToString());
                        TextBoxFlightID.Text = (ds.Tables[0].Rows[0]["Fid"].ToString());
                    }
                    else
                    {
                        Response.Write("<script>alert('Flight ID Not available to update')</script>");
                    }
                }
                else
                {
                    Response.Write("<script>alert('Flight with FlightID: " + fnumToUpdate + " not found')</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Flight was not submitted in right format please check ex:AA1234')</script>");
            }
        }

        protected void ButtonCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/FlightOperations.aspx");
        }


        protected void ButtonUpdateFlight_Click(object sender, EventArgs e)
        {
            string fnum = TextBoxUpdatedFlightNum.Text;
            int seats = Convert.ToInt32(TextBoxUpdatedSeats.Text);
            int airid = Convert.ToInt32(DDLFlightReseration.SelectedValue);
            int fid = Convert.ToInt32(TextBoxFlightID.Text);
            DatabaseConnection datacon = new DatabaseConnection();
            int i = datacon.UpdateFlight(fnum, seats, airid, fid);
            if(i==1)
            {
                Response.Write("<script>alert('The new FlightID generated is: " + fnum + "')</script>");
                UpdateFlighNumTable.Visible = false;
            }
            else
            {
                Response.Write("<script>alert('FlightID not updated')</script>");
                UpdateFlighNumTable.Visible = false;
            }
        }

        protected void TextBoxUpdatedFlightNum_TextChanged(object sender, EventArgs e)
        {
            string flightnum = TextBoxUpdatedFlightNum.Text;
            Regex exp = new Regex(@"^[A-Z]{2}\d{4}$");
            Match mat = exp.Match(flightnum);
            if (flightnum == "")
            {
                LabelFlightnumCheck.Text = "Flight Number cannot be Empty";
                LabelFlightnumCheck.Visible = true;
            }
            else if (mat.Success && flightnum != "")
            {
                LabelFlightnumCheck.Visible = false;
                DatabaseConnection dataconn = new DatabaseConnection();
                int fnum = dataconn.checkFlightNum(flightnum);
                if (fnum > 0)
                {
                    TextBoxUpdatedFlightNum.BackColor = ColorTranslator.FromHtml("#F08080");
                }
                else
                {
                    TextBoxUpdatedFlightNum.BackColor = ColorTranslator.FromHtml("#00FF7F");
                }

            }
            else if (!mat.Success)
            {
                LabelFlightnumCheck.Text = "Flight Number Must be in pattern AA1234";
                LabelFlightnumCheck.Visible = true;
            }
        }

        protected void ButtonUpdateCancel_Click(object sender, EventArgs e)
        {
            UpdateFlighNumTable.Visible = false;
        }
    }
}