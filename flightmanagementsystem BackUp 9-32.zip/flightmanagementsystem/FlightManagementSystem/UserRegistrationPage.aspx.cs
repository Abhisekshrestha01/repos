﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseOperation;

namespace FlightManagementSystem
{
    public partial class UserRegistrationPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) {
               
                DatabaseConnection c1 = new DatabaseConnection();
                DataSet ds = c1.GetRoleDropDownData();
                ddlRole.DataTextField = "Role";
                ddlRole.DataValueField = "RID";
                ddlRole.DataSource = ds;
                ddlRole.DataBind();
                ListItem li = new ListItem("Select","-1");
                ddlRole.Items.Insert(0,li);
                ddlRole.SelectedValue = "-1";

                //For City
                ds = c1.GetStateData();
                ddlState.DataTextField = "STATE_CODE";
                ddlState.DataValueField = "STATE_NAME";
                ddlState.DataSource = ds;
                ddlState.DataBind();
                ListItem si = new ListItem("Select", "-1");
                ddlState.Items.Insert(0, si);
                ddlState.SelectedValue = "-1";
                ListItem ci = new ListItem("Select", "-1");
                ddlCity.Items.Insert(0, ci);
                ddlCity.SelectedValue = "-1";
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            ClearAll();
        }


        private void ClearAll()
        {
            txtFN.Text = "";
            txtLN.Text= "";
            txtEmail.Text = "";
            ddlState.SelectedIndex = -1;
            ddlState.SelectedIndex = -1;
            ddlRole.SelectedIndex = -1;
            txtPassword.Text = "";
            txtPhone.Text = "";
            txtStateId.Text = "";
            txtStreetAddress.Text = "";
            txtUserName.Text = "";
            txtZIPCode.Text = "";
            ddlRole.SelectedIndex = -1;
            ddlState.SelectedIndex = -1;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                DatabaseConnection dc = new DatabaseConnection();
                if (!dc.ValidateUniqueUserName(txtUserName.Text))
                {
                    RegistrationClass rc = new RegistrationClass();
                    rc.FirstName = txtFN.Text;
                    rc.LastName = txtLN.Text;
                    rc.Email = txtEmail.Text;
                    rc.PhoneNo = txtPhone.Text;
                    rc.StateId = txtStateId.Text;
                    rc.StreetAddress = txtStreetAddress.Text;
                    rc.City = ddlCity.SelectedValue;
                    rc.State = ddlState.SelectedItem.Value;
                    rc.ZIPCode = Convert.ToInt32(txtZIPCode.Text);
                    rc.UserName = txtUserName.Text;
                    string un = txtUserName.Text;
                    rc.Password = txtPassword.Text;
                    rc.Role = Convert.ToInt32(ddlRole.SelectedItem.Value);                   
                    bool res = dc.InsertData(rc);
                    if (res)
                    {
                        lblMessage.ForeColor = System.Drawing.Color.GreenYellow;
                        Response.Redirect("Login.aspx");
                        dc.GetActivationParameter(un);
                        ClearAll();
                    }
                    else
                    {
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                        lblMessage.Text = "Registration failed try again";
                    }
                }
                else
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "UserName not valid";
                    lblUserName.ForeColor = System.Drawing.Color.Red;
                }
                
            }
            else
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Registration failed try again";
            }
        }

        protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlState.SelectedValue == "-1")
            {
                ddlCity.SelectedIndex = -1;
                ddlCity.Enabled = false;
            }
            else
            {
                ddlCity.Enabled = true;
                string stateName = ddlState.SelectedValue;
                DatabaseConnection c1 = new DatabaseConnection();
                DataSet ds = c1.GetCityData(stateName);
                ddlCity.DataTextField = "City";
                ddlCity.DataValueField = "City";
                ddlCity.DataSource = ds;
                ddlCity.DataBind();
                ListItem li = new ListItem("Select", "-1");
                ddlCity.Items.Insert(0, li);
                ddlCity.SelectedValue = "-1";

            }
        }
    }
}