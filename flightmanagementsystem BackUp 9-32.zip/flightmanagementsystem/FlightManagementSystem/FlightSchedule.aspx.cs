﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseOperation;
using System.Data;
using System.Data.SqlClient;

namespace FlightManagementSystem
{
    public partial class FlightSchedule : System.Web.UI.Page
    {
        DatabaseConnection dc = new DatabaseConnection();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                Calendar1.Visible = false;
                DatabaseConnection dc = new DatabaseConnection();

                DataSet ds2 = new DataSet();
                ds2 = dc.DropDownAirline();
                selectedAirlineName.DataSource = ds2.Tables[0];
                selectedAirlineName.DataTextField = "AirlineName";
                selectedAirlineName.DataValueField = "AirId";
                selectedAirlineName.DataBind();
                ListItem liAirline = new ListItem("Select Airlines", "-1");
                selectedAirlineName.Items.Insert(0, liAirline);

                selectedDepartureState.DataSource = dc.Getdata("spgetStates", null);
                selectedDepartureState.DataValueField = "STATE_CODE";
                selectedDepartureState.DataTextField = "STATE_NAME";
                selectedDepartureState.DataBind();

                ListItem liState = new ListItem("Select State", "-1");
                selectedDepartureState.Items.Insert(0, liState);

                selectedArrivalState.DataSource = dc.Getdata("spgetStates", null);
                selectedArrivalState.DataValueField = "STATE_CODE";
                selectedArrivalState.DataTextField = "STATE_NAME";
                selectedArrivalState.DataBind();

                selectedArrivalState.Items.Insert(0, liState);

                selectedDepartureCity.Visible = false;
                selectedArrivalCity.Visible = false;

            }
        }


        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            txtFlightDate.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }
        }

        protected void Submit(object sender, EventArgs e)
        {
            //DateTime time = DateTime.Parse(Request.Form[txtTime.UniqueID]);

        }

        protected void selectedDepartureState_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (selectedDepartureState.SelectedIndex == 0)
            {
                selectedDepartureCity.Enabled = false;
            }
            else
            {
                selectedDepartureCity.Visible = true;

                selectedDepartureCity.Visible = true;
                SqlParameter parameter = new SqlParameter("@iDcode", selectedDepartureState.SelectedItem.Value);
                DataSet DS = dc.Getdata("spGetCityByStates", parameter);
                selectedDepartureCity.DataSource = DS;
                selectedDepartureCity.DataValueField = "ID";
                selectedDepartureCity.DataTextField = "CITY";
                selectedDepartureCity.DataBind();
                ListItem liCity = new ListItem("Select City", "-1");
                selectedDepartureCity.Items.Insert(0, liCity);
            }
        }


        protected void selectedArrivalState_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (selectedArrivalState.SelectedIndex == 0)
            {
                selectedArrivalCity.Enabled = false;
            }
            else
            {
                selectedArrivalCity.Visible = true;

                SqlParameter parameter = new SqlParameter("@iDcode", selectedArrivalState.SelectedItem.Value);
                DataSet DS = dc.Getdata("spGetCityByStates", parameter);
                selectedArrivalCity.DataSource = DS;
                selectedArrivalCity.DataValueField = "ID";
                selectedArrivalCity.DataTextField = "CITY";
                selectedArrivalCity.DataBind();
                ListItem liCity = new ListItem("Select City", "-1");
                selectedArrivalCity.Items.Insert(0, liCity);

            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            dc.AddSchedule(selectedAirlineName.SelectedItem.Value, selectedAirlineFlightNum.SelectedItem.Value, selectedDepartureState.SelectedItem.Value, int.Parse(selectedDepartureCity.SelectedItem.Value), selectedArrivalState.SelectedItem.Value, int.Parse(selectedArrivalCity.SelectedItem.Value), txtFlightTime.Text, txtDuration.Text, txtFlightDate.Text, int.Parse(txtCost.Text));
            Response.Redirect("~/EditSchedule.aspx");
        }

        protected void selectedAirlineName_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedAirlineFlightNum.Visible = true;

            SqlParameter parameter = new SqlParameter("@id", selectedAirlineName.SelectedItem.Value);
            DataSet DS = dc.Getdata("spGetFlightNumByAID", parameter);
            selectedAirlineFlightNum.DataSource = DS;
            selectedAirlineFlightNum.DataValueField = "FlightNum";
            selectedAirlineFlightNum.DataTextField = "FlightNum";
            selectedAirlineFlightNum.DataBind();
            ListItem FlightList = new ListItem("Select Flight Number", "-1");
            selectedArrivalCity.Items.Insert(0, FlightList);
        }

        protected void selectedAirlineFlightNum_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (selectedAirlineFlightNum.SelectedIndex == 0)
            {

            }
            else
            {
                
            }
        }
    }
}