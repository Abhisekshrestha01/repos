﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FlightManagementSystem
{
    public partial class MasterSite : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["RoleId"]!=null)
            {
                Button1.Visible = true;
                Button2.Visible = true;
            }
            else
            {
                Button1.Visible = false;
                Button2.Visible = false;
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect("~/HomePage.aspx");
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            
            Response.Redirect("~/UpdateForm.aspx");
        }
    }
}