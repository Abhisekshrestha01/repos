﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FlightManagementSystem
{
    public partial class StaffHomePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void FLights_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/FlightOperations.aspx");
        }

        protected void StaffHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/StaffHomePage.aspx");
        }

        protected void Schedules_Click(object sender, EventArgs e)
        {
            Response.Redirect("EditSchedule.aspx");
        }
    }
}