﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FlightManagementSystem
{
    public partial class HomePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            string email = "flightmanagementsystemimcs@gmail.com";
            string email1 = txtemail.Text;
            string adminemail = "abhisek.shrestha1991@gmail.com";
            string name = txtname.Text;
            string comment = txtmessage.Text;
            MailMessage mail = new MailMessage();
            MailMessage mail1 = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

            mail.From = new MailAddress(email);
            mail.To.Add(email1);
            mail.Subject = "Admin is successfully notified";
            mail.Body = "Hello " + name + ",\n Admin has been successfully notified about the issus:\n\""+ comment+"\" \n\n With Regards, \n Flight Management System \n Dallas, TX";

            mail1.From = new MailAddress(email);
            mail1.To.Add(adminemail);
            mail1.Subject = "Comment from customer";
            mail1.Body = "Hello Admin,\n "+name+" has some comment on your system:\n\"" + comment + "\" \n\n With Regards, \n Flight Management System \n Dallas, TX";

            SmtpServer.Port = 587;
            SmtpServer.Credentials = new System.Net.NetworkCredential("flightmanagementsystemimcs@gmail.com", "flight@123");
            SmtpServer.EnableSsl = true;
            try
            {
                SmtpServer.Send(mail);
                SmtpServer.Send(mail1);
                Response.Write("<script>alert('Successfully Sent...');</script>");
            }
            catch (Exception ex)
            {
                Exception ex2 = ex;
                string errorMessage = string.Empty;
                Response.Write("<script>alert('Sending Failed...');</script>");
            }
        }
    }
}