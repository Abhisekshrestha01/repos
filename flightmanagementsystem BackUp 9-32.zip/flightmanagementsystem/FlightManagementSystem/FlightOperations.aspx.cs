﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FlightManagementSystem
{
    public partial class FlightOperations : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void FlightAddition_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/FlightsOperationsAdd.aspx");
        }

        protected void FlightsDisplay_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/FlightsOperationsView.aspx");
        }

        protected void StaffHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/StaffHomePage.aspx");
        }

        protected void FlightsManipualation_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/FlightsOperationUpdateDelete.aspx");
        }
    }
}