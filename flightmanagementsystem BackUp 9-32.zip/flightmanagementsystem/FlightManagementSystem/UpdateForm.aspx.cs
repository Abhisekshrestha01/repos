﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseOperation;

namespace FlightManagementSystem
{
    public partial class UpdateForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DatabaseConnection c2 = new DatabaseConnection();
                DataSet ds = c2.GetRoleDropDownData();
                //For City
                ds = c2.GetStateData();
                ddlState.DataTextField = "STATE_CODE";
                ddlState.DataValueField = "STATE_NAME";
                ddlState.DataSource = ds;
                ddlState.DataBind();
                ListItem si = new ListItem("Select", "-1");
                ddlState.Items.Insert(0, si);
                ddlState.SelectedValue = "-1";

                if (Session["username"] != null) {
                    string username = Session["username"].ToString();
                    DatabaseConnection c1 = new DatabaseConnection();
                    RegistrationClass rc =  c1.GetAllUserDataForUpdate(username);
                    txtFN.Text = rc.FirstName;
                    txtLN.Text = rc.LastName;
                    txtEmail.Text = rc.Email;
                    txtPhone.Text = rc.PhoneNo;
                    txtStateId.Text = rc.StateId;
                    txtStreetAddress.Text = rc.StreetAddress;
                   
                    txtZIPCode.Text = rc.ZIPCode.ToString();
                    
                }
                
            }
        }

        

        protected void btnClear_Click(object sender, EventArgs e)
        {
            ClearAll();
        }
        private void ClearAll()
        {
            txtFN.Text = "";
            txtLN.Text = "";
            txtEmail.Text = "";
            ddlCity.SelectedIndex = -1;
            ddlState.SelectedIndex = -1;
            txtPhone.Text = "";
            txtStateId.Text = "";
            txtStreetAddress.Text = "";           
            txtZIPCode.Text = "";
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (Session["username"] != null) {
                RegistrationClass rc = new RegistrationClass();
                rc.UserName = Session["username"].ToString();
                rc.FirstName = txtFN.Text;
                rc.LastName = txtLN.Text;
                rc.Email = txtEmail.Text;
                rc.PhoneNo = txtPhone.Text;
                rc.StateId = txtStateId.Text;
                rc.StreetAddress = txtStreetAddress.Text;
                rc.City = ddlCity.SelectedValue;
                rc.State = ddlState.SelectedItem.Value;
                rc.ZIPCode = Convert.ToInt32(txtZIPCode.Text);
                DatabaseConnection dc = new DatabaseConnection();
                if (dc.UpdateUserInformation(rc))
                {
                    lblMessage.ForeColor = System.Drawing.Color.GreenYellow;
                    lblMessage.Text = "Update Sucessful";
                }
                else
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Update unsucessful, Try Again";
                }
            }
        }

        protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlState.SelectedValue == "-1")
            {
                ddlCity.SelectedIndex = -1;
                ddlCity.Enabled = false;
            }
            else
            {
                ddlCity.Enabled = true;
                string stateName = ddlState.SelectedValue;
                DatabaseConnection c1 = new DatabaseConnection();
                DataSet ds = c1.GetCityData(stateName);
                ddlCity.DataTextField = "City";
                ddlCity.DataValueField = "City";
                ddlCity.DataSource = ds;
                ddlCity.DataBind();
                ListItem li = new ListItem("Select", "-1");
                ddlCity.Items.Insert(0, li);
                ddlCity.SelectedValue = "-1";

            }
        }
    }
}