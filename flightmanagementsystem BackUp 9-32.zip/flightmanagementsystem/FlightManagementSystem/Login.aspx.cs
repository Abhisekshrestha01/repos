﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseOperation;
using LoginValidation;
namespace FlightManagementSystem
{
    public partial class Login : System.Web.UI.Page
    {
        DatabaseConnection db = new DatabaseConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if(Request.QueryString["id"]!=null)
                {
                    Response.Write("<script>alert('Password Changed Successfully')</script>");
                }
                if(Request.Cookies["Username"] != null && Request.Cookies["Password"] != null)
                {
                    Login_txtUserName.Text = Request.Cookies["Username"].Value;
                    Login_txtPassword.Attributes["value"] = Request.Cookies["Password"].Value;
                }
            }

        }

        protected void Login_btnLogin_Click(object sender, EventArgs e)
        {
            
            validationLogin login = new validationLogin();
            validationLogin returnValue = new validationLogin();
            int check = 0;
            string login_Username = Login_txtUserName.Text;
            string login_Password = Login_txtPassword.Text;
             
            returnValue = login.validateUser(login_Username, login_Password, out check);
            int uid = db.getUserid(login_Username);
            Session["UId"] = uid;
            if (check == 1)
                
            {
               if(Login_checkRememberMe.Checked)
                {

                    Response.Cookies["Username"].Value = Login_txtUserName.Text;
                    Response.Cookies["Password"].Value = Login_txtPassword.Text;
                    Response.Cookies["Username"].Expires = DateTime.Now.AddMinutes(5);
                    Response.Cookies["Password"].Expires = DateTime.Now.AddMinutes(5);

                }
                else
                {
                    Response.Cookies["Username"].Expires = DateTime.Now.AddMinutes(-1);
                    Response.Cookies["Password"].Expires = DateTime.Now.AddMinutes(-1);
                }
                Session["Username"] = returnValue;
                switch (returnValue.RoleID)
                {
                    case 1:
                        {
                            Response.Redirect("~/Admin");
                            break;

                        }
                    case 2:
                        {
                            Response.Redirect("~/StaffHomePage");
                            break;

                        }
                    case 3:
                        {
                            Response.Redirect("~/UserPage");
                            break;

                        }
                    default:
                        {
                            break;
                        }
                }
            }


            else
            {
                string status = "No account found";
                lblStatus.Text = status;
               

            }

        }

        protected void btnForgetPassword_Click(object sender, EventArgs e)
        {
            
            Response.Redirect("~/ForgetPassword.aspx");
        }
    }
}