﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseOperation
{
    class SendEmail
    {
        public void SendStatusSetEmail(string toEmail, string username, string uniqueId)
        {
            MailMessage message = new MailMessage("sthasgn1@gmail.com", toEmail);

            StringBuilder sb = new StringBuilder();
            sb.Append("Dear " + username + ",<br/>");
            sb.Append("Please click this link to activate your account");
            sb.Append("<br/>");
            sb.Append("http://localhost/FlightRegistration/LoginForm.aspx?uid=" + uniqueId);
            sb.Append("<br/><br/>");
            sb.Append("<b>IMCS Flights</b>");

            message.IsBodyHtml = true;

            message.Subject = "Account activation link";
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587);

            smtpClient.Credentials = new System.Net.NetworkCredential()
            {
                UserName = "flightmanagementsystemimcs@gmail.com",
                Password = "flight@123"
            };

            smtpClient.EnableSsl = true;
            smtpClient.Send(message);

        }
    }
}
