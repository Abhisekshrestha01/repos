﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseOperation;

namespace FlightManagementSystem
{
    public partial class UserPage : System.Web.UI.Page
    {
        DatabaseConnection db = new DatabaseConnection();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session["statefrom"] = "";
                Session["cityFrom"] = "";
                Session["stateto"] = "";
                Session["cityto"] = "";
                Session["date"] = "";
                Session["seats"] = "";
                GridView1.Visible = false;
                Calendar1.Visible = false;
                
                DropDownStateFrom.DataSource = db.Getdata("spgetStates", null);
                DropDownStateFrom.DataValueField = "STATE_CODE";
                DropDownStateFrom.DataTextField = "STATE_NAME";
                DropDownStateFrom.DataBind();


                GridView3.Visible = false;

                ListItem liState = new ListItem("Select State", "-1");
                DropDownStateFrom.Items.Insert(0, liState);

                DropDownStateTo.DataSource = db.Getdata("spgetStates", null);
                DropDownStateTo.DataValueField = "STATE_CODE";
                DropDownStateTo.DataTextField = "STATE_NAME";
                DropDownStateTo.DataBind();

                DropDownStateTo.Items.Insert(0, liState);


                DropDownCityFrom.Visible = false;
                DropDownCityTo.Visible = false;
                int uid = int.Parse(Session["UId"].ToString());
                SqlParameter parameter1 = new SqlParameter("@uidd", uid);

                DataSet DS = db.GetUserInputde("spGetUserdetailByUseri", parameter1);
                GridView2.DataSource = DS;
                GridView2.DataBind();



            }
        }
        
        protected void DropDownStateFrom_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownCityFrom.SelectedIndex == 0)
            {

            }
            else
            {

                DropDownCityFrom.Visible = true;
                SqlParameter parameter = new SqlParameter("@iDcode", DropDownStateFrom.SelectedItem.Value);
                DataSet DS = db.Getdata("spGetCityByStates", parameter);
                DropDownCityFrom.DataSource = DS;
                DropDownCityFrom.DataValueField = "ID";
                DropDownCityFrom.DataTextField = "CITY";
                DropDownCityFrom.DataBind();
                ListItem liCity = new ListItem("Select City", "-1");
                DropDownCityFrom.Items.Insert(0, liCity);
            }
        }

        protected void DropDownStateTo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownCityTo.SelectedIndex == 0)
            {

            }
            else
            {
                DropDownCityTo.Visible = true;
                SqlParameter parameter = new SqlParameter("@iDcode", DropDownStateTo.SelectedItem.Value);
                DataSet DS = db.Getdata("spGetCityByStates", parameter);
                DropDownCityTo.DataSource = DS;
                DropDownCityTo.DataValueField = "ID";
                DropDownCityTo.DataTextField = "CITY";
                DropDownCityTo.DataBind();
                ListItem liCity = new ListItem("Select City", "-1");
                DropDownCityTo.Items.Insert(0, liCity);
            }

        }


        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }

        }
        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            txtdate.Text = Calendar1.SelectedDate.ToString("d");
            Calendar1.Visible = false;
        }
        protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
        {
            if (e.Day.IsOtherMonth)
            {
                e.Day.IsSelectable = false;
                e.Cell.BackColor = System.Drawing.Color.Red;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            GridView1.Visible = true;
            Session["statefrom"] = DropDownStateFrom.SelectedItem.Value;
            Session["cityFrom"] = DropDownCityFrom.SelectedItem.Value;
            Session["stateto"] = DropDownStateTo.SelectedItem.Value;
            Session["cityto"] = DropDownCityTo.SelectedItem.Value;
            Session["date"] = txtdate.Text;
            Session["seats"] = txtSeats.Text;

            SqlParameter parameter1 = new SqlParameter("@DepartureState", Session["statefrom"].ToString());
            SqlParameter parameter2 = new SqlParameter("@DepartureCity", Session["cityFrom"].ToString());
            SqlParameter parameter3 = new SqlParameter("@ArrivalState", Session["stateto"].ToString());
            SqlParameter parameter4 = new SqlParameter("@ArrivalCity", Session["cityto"].ToString());
            SqlParameter parameter5 = new SqlParameter("@Date", Session["date"].ToString());
            SqlParameter parameter6 = new SqlParameter("@seat", int.Parse(Session["seats"].ToString()));
            DataSet DS = db.GetUserInput("spGetFlightByUserInput", parameter1, parameter2, parameter3, parameter4, parameter5, parameter6);
            GridView1.DataSource = DS;
            GridView1.DataBind();


        }
        protected void gridview3bind()
        {
            int uid = int.Parse(Session["UId"].ToString());
            SqlParameter parameter1 = new SqlParameter("@uidd", uid);

            DataSet DS = db.GetUserInputde("spGetUserdetailByUseriOld", parameter1);
            GridView3.DataSource = DS;
            GridView3.DataBind();
        }
        protected void InsertDatabase(object sender, EventArgs e)
        {

            string ScheduleId = ((sender as LinkButton).CommandArgument);
            db.InsertIntoSchedule(int.Parse(ScheduleId), int.Parse(Session["UId"].ToString()), int.Parse(Session["seats"].ToString()), 1, DateTime.Now.Date.ToString());

            SqlParameter parameter = new SqlParameter("@uidd", int.Parse(Session["UId"].ToString()));

            DataSet DS = db.GetUserInputde("spGetUserdetailByUseri", parameter);
            GridView2.DataSource = DS;
            GridView2.DataBind();


            SqlParameter parameter1 = new SqlParameter("@DepartureState", Session["statefrom"].ToString());
            SqlParameter parameter2 = new SqlParameter("@DepartureCity", Session["cityFrom"].ToString());
            SqlParameter parameter3 = new SqlParameter("@ArrivalState", Session["stateto"].ToString());
            SqlParameter parameter4 = new SqlParameter("@ArrivalCity", Session["cityto"].ToString());
            SqlParameter parameter5 = new SqlParameter("@Date", Session["date"].ToString());
            SqlParameter parameter6 = new SqlParameter("@seat", Session["seats"].ToString());
            DataSet DS1 = db.GetUserInput("spGetFlightByUserInput", parameter1, parameter2, parameter3, parameter4, parameter5, parameter6);
            GridView1.DataSource = DS1;
            GridView1.DataBind();



        }

        protected void Deleteitem(object sender, EventArgs e)
        {

            string UserInputId = ((sender as LinkButton).CommandArgument);
            db.DeleteInput(int.Parse(UserInputId));
            SqlParameter parameter = new SqlParameter("@uidd", int.Parse(Session["UId"].ToString()));

            DataSet DS = db.GetUserInputde("spGetUserdetailByUseri", parameter);
            GridView2.DataSource = DS;
            GridView2.DataBind();

            SqlParameter parameter1 = new SqlParameter("@DepartureState", Session["statefrom"].ToString());
            SqlParameter parameter2 = new SqlParameter("@DepartureCity", Session["cityFrom"].ToString());
            SqlParameter parameter3 = new SqlParameter("@ArrivalState", Session["stateto"].ToString());
            SqlParameter parameter4 = new SqlParameter("@ArrivalCity", Session["cityto"].ToString());
            SqlParameter parameter5 = new SqlParameter("@Date", Session["date"].ToString());
            SqlParameter parameter6 = new SqlParameter("@seat", Session["seats"].ToString());
            DataSet DS1 = db.GetUserInput("spGetFlightByUserInput", parameter1, parameter2, parameter3, parameter4, parameter5, parameter6);
            GridView1.DataSource = DS1;
            GridView1.DataBind();

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            if(GridView3.Visible)
            {
                GridView3.Visible = false;
                gridview3bind();
            }
            else
            {
                GridView3.Visible = true;
                gridview3bind();
            }
            
        }
    }
}