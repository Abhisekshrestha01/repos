﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LoginValidation;
using DatabaseOperation;
namespace FlightManagementSystem
{
    public partial class Login : System.Web.UI.Page
    {
        DatabaseConnection db = new DatabaseConnection();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Login_btnLogin_Click(object sender, EventArgs e)
        {
            validationLogin login = new validationLogin();
            validationLogin returnValue = new validationLogin();
            int check = 0;
            string login_Username = Login_txtUserName.Text;
            string login_Password = Login_txtPassword.Text;
             
            returnValue = login.validateUser(login_Username, login_Password, out check);
            int uid = db.getUserid(login_Username);
            Session["UId"] = uid;
            if (check == 1)
                
            {
                Session["Username"] = returnValue.username;
                Session["RoleId"] = returnValue.RoleID;
                
                switch (returnValue.RoleID)
                {
                    case 1:
                        {
                            Response.Redirect("~/Admin");
                            break;

                        }
                    case 2:
                        {
                            Response.Redirect("~/StaffHomePage.aspx");
                            break;

                        }
                    case 3:
                        {
                            Response.Redirect("~/UserPage.aspx");
                            break;

                        }
                    default:
                        {
                            break;
                        }
                }
            }


            else
            {
                string status = "No account found";
                lblStatus.Text = status;
                Response.Write(lblStatus);

            }

        }

        protected void btnForgetPassword_Click(object sender, EventArgs e)
        {
            
            Response.Redirect("~/ForgetPassword.aspx");
        }
    }
}