﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseOperation;

namespace FlightManagementSystem
{
    public partial class FlightOperationsView : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                gridviewbind();
            }
        }
        protected void gridviewbind()
        {
            DatabaseConnection datacon = new DatabaseConnection();
            gridviewViewFlights.DataSource = datacon.gridviewFlights();
            gridviewViewFlights.DataBind();
        }

        protected void BackHomeButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/FlightOperations.aspx");
        }

        protected void gridviewViewFlights_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
        {
            gridviewViewFlights.CurrentPageIndex = e.NewPageIndex;
            gridviewbind();
        }
    }
}