﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseOperation;

namespace FlightManagementSystem
{
    public partial class ActivationPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            if (Request.QueryString["uid"] != null)
            {
                string guid = Request.QueryString["uid"];
                DatabaseConnection dc = new DatabaseConnection();
                if (dc.checkActivationLinkValidation(guid))
                {
                    if (dc.ActivateUser(guid))
                    {
                        Response.Redirect("~/LoginForm.aspx");
                    }
                }
                else
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Activation Failed, Either the link is invalid or expired";
                }
            }


        }
    }
}