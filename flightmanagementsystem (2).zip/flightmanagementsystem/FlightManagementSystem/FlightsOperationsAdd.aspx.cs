﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DatabaseOperation;
using System.Drawing;
using System.Text.RegularExpressions;

namespace FlightManagementSystem
{
    public partial class FlightsOperations : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
                bindDDLData();
                
            }
        }
        protected void bindDDLData()
        {
            DatabaseConnection dataconn = new DatabaseConnection();
            DDLFlightReseration.DataSource =dataconn.ddlAirlineCompany() ;
            DDLFlightReseration.DataBind();
            DDLFlightReseration.DataTextField = "AirlineName";
            DDLFlightReseration.DataValueField = "AirId";
            DDLFlightReseration.DataBind();
            DDLFlightReseration.Items.Insert(0, new ListItem("-----SELECT-----", "0"));
        }

        

        protected void SubmitAddFlight_Click(object sender, EventArgs e)
        {
            if(TextBoxFlightNumber.Text=="")
            {
                ValidationlabelFlightNum.Text = "Flight Number cannot be Empty";
                ValidationlabelFlightNum.Visible = true;
            }
            int airid = Convert.ToInt32(DDLFlightReseration.SelectedValue);
            string flightnum = TextBoxFlightNumber.Text;
            int seats=Convert.ToInt32(TextBoxSeats.Text);
            DatabaseConnection dataconn = new DatabaseConnection();
            int i=dataconn.FlightDetailsInsert(airid, flightnum, seats);
            if(i!=0)
            {
                Response.Write("<script>alert('New Flight Registered Successfully FlightNum: " + flightnum + "')</script>");
                Response.Redirect("~/FlightOperations.aspx");
            }
            else
            {
                Response.Write("<script>alert('New Flight was not registered.')</script>");
            }

        }

        protected void CancelAddFlight_Click(object sender, EventArgs e)
        {

            DDLFlightReseration.SelectedValue = "0";
            TextBoxFlightNumber.Text = "";
            TextBoxSeats.Text = "";
            Response.Redirect("~/FlightOperations.aspx");
        }

        protected void TextBoxFlightNumber_TextChanged(object sender, EventArgs e)
        {
            string flightnum = TextBoxFlightNumber.Text;
            Regex exp = new Regex(@"^[A-Z]{2}\d{4}$");
            Match mat = exp.Match(flightnum);
            if(flightnum=="")
            {
                ValidationlabelFlightNum.Text = "Flight Number cannot be Empty";
                ValidationlabelFlightNum.Visible = true;
            }
            else if (mat.Success && flightnum != "")
            {
                ValidationlabelFlightNum.Visible = false;
                DatabaseConnection dataconn = new DatabaseConnection();
                int fnum = dataconn.checkFlightNum(flightnum);
                if (fnum > 0)
                {
                    TextBoxFlightNumber.BackColor = ColorTranslator.FromHtml("#F08080");
                }
                else
                {
                    TextBoxFlightNumber.BackColor = ColorTranslator.FromHtml("#00FF7F");
                }

            }
            else if(!mat.Success)
            {
                ValidationlabelFlightNum.Text = "Flight Number Must be in pattern AA1234";
                ValidationlabelFlightNum.Visible = true;
            }


        }
    }
}