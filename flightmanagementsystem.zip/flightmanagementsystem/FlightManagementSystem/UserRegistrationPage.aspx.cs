﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseOperation;

namespace FlightManagementSystem
{
    public partial class UserRegistrationPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) {
               
                DatabaseConnection c1 = new DatabaseConnection();
                DataSet ds = c1.GetRoleDropDownData();
                ddlRole.DataTextField = "Role";
                ddlRole.DataValueField = "RID";
                ddlRole.DataSource = ds;
                ddlRole.DataBind();
                ListItem li = new ListItem("Select","-1");
                ddlRole.Items.Insert(0,li);
                ddlRole.SelectedValue = "-1";
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            ClearAll();
        }


        private void ClearAll()
        {
            txtFN.Text = "";
            txtLN.Text= "";
            txtEmail.Text = "";
            txtCity.Text = "";
            txtPassword.Text = "";
            txtPhone.Text = "";
            txtStateId.Text = "";
            txtStreetAddress.Text = "";
            txtUserName.Text = "";
            txtZIPCode.Text = "";
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                RegistrationClass rc = new RegistrationClass();
                rc.FirstName = txtFN.Text;
                rc.LastName = txtLN.Text;
                rc.Email = txtEmail.Text;
                rc.PhoneNo = txtPhone.Text;
                rc.StateId = txtPhone.Text;
                rc.StreetAddress = txtPhone.Text;
                rc.City = txtCity.Text;
                rc.State = ddlState.SelectedItem.Value;
                rc.ZIPCode = Convert.ToInt32(txtZIPCode.Text);
                rc.UserName = txtUserName.Text;
                rc.Password = txtPassword.Text;
                rc.Role =Convert.ToInt32(ddlRole.SelectedItem.Value);
                DatabaseConnection dc = new DatabaseConnection();
                bool res = dc.InsertData(rc);
                if (res)
                {
                    lblMessage.ForeColor = System.Drawing.Color.GreenYellow;
                    lblMessage.Text = "Sucessfully Registered";
                    ClearAll();
                }
                else
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Registration failed try again";
                }
                
            }
            else
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Registration failed try again";
            }
        }
    }
}