﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseOperation;
namespace LoginValidation
{
    public class validationLogin
    {
      public int   validateUser(string _username,string _password)
        {
            RegistrationClass register = new RegistrationClass();
            register.UserName = _username;
            register.Password = _password;
        }
    }
}
