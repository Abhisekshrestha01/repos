﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseOperation
{
    public class DatabaseConnection
    {
        String CS = System.Configuration.ConfigurationManager.ConnectionStrings["DBCS"].ToString();
        public DataSet Getdata(string spname, SqlParameter spparameter)
        {

            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter sda = new SqlDataAdapter(spname, con);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                if (spparameter != null)
                {
                    sda.SelectCommand.Parameters.Add(spparameter);
                }
                DataSet ds = new DataSet();
                sda.Fill(ds);
                return ds;
            }

        }
        public DataSet GetUserInput(string spname, SqlParameter spparameter1, SqlParameter spparameter2, SqlParameter spparameter3, SqlParameter spparameter4, SqlParameter spparameter5, SqlParameter spparameter6)
        {
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter sda = new SqlDataAdapter(spname, con);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sda.SelectCommand.Parameters.Add(spparameter1);
                sda.SelectCommand.Parameters.Add(spparameter2);
                sda.SelectCommand.Parameters.Add(spparameter3);
                sda.SelectCommand.Parameters.Add(spparameter4);
                sda.SelectCommand.Parameters.Add(spparameter5);
                sda.SelectCommand.Parameters.Add(spparameter6);

                DataSet ds = new DataSet();
                sda.Fill(ds);
                return ds;
            }
        }
        public void InsertIntoSchedule(int SId, int UId, int seats, int status, string date)
        {
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand("spUserInputInsert", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UId", UId);
                cmd.Parameters.AddWithValue("@SId", SId);
                cmd.Parameters.AddWithValue("@Seats", seats);
                cmd.Parameters.AddWithValue("@Status", status);
                cmd.Parameters.AddWithValue("@Date", date);
                con.Open();
                cmd.ExecuteNonQuery();


            }

        }

        public DataSet GetUserInputde(string spname, SqlParameter spparameter)
        {
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter sda = new SqlDataAdapter(spname, con);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sda.SelectCommand.Parameters.Add(spparameter);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                return ds;
            }
        }

        public void DeleteInput(int id)
        {
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand("spDeleteItemById", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", id);
                con.Open();
                cmd.ExecuteNonQuery();
            }
            }

    }
}
